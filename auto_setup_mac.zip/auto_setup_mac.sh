#!/bin/bash

# Prompt for GitHub username
read -p "Enter your GitHub username: " username

# Clone the repo and run install
cd /Users/$USER/Desktop || exit
git clone https://github.com/minivega/lafamilia
cd lafamilia || exit

# Run install script if it exists
if [ -f install.sh ]; then
    chmod +x install.sh
    ./install.sh
else
    echo "install.sh not found in the repository."
fi
